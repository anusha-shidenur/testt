export interface LoginRequest {
  username: string;
  password: string;
}

export interface LoginResponse {
  token: string;
  username: string;
  role: 'OPERATOR' | 'SUPERVISOR' | 'ADMIN';
  expiresIn: number;
}

export interface AuthUser {
  username: string;
  role: 'OPERATOR' | 'SUPERVISOR' | 'ADMIN';
}
