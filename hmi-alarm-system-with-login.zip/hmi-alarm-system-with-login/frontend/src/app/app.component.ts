import { Component, inject } from '@angular/core';
import { RouterOutlet, RouterLink, RouterLinkActive } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService } from './core/services/auth.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, RouterLink, RouterLinkActive, CommonModule],
  template: `
    <div class="app-shell">
      <header class="top-nav">
        <div class="nav-brand">
          <span class="nav-icon">⚠</span>
          <span class="nav-title">HMI Alarm Board</span>
        </div>
        <nav class="nav-links">
          <a routerLink="/alarms" routerLinkActive="active">Dashboard</a>
        </nav>
        @if (auth.currentUser(); as user) {
          <div class="nav-user">
            <span class="user-badge role-{{ user.role.toLowerCase() }}">{{ user.role }}</span>
            <span class="user-name">{{ user.username }}</span>
            <button class="logout-btn" (click)="auth.logout()" title="Sign out">⏻</button>
          </div>
        }
      </header>
      <main class="content">
        <router-outlet />
      </main>
    </div>
  `,
  styles: [`
    .app-shell { min-height: 100vh; background: #0f1117; }
    .top-nav {
      display: flex; align-items: center; justify-content: space-between;
      padding: 0 2rem; height: 60px; background: #161b27;
      border-bottom: 1px solid #2a3040; position: sticky; top: 0; z-index: 100;
    }
    .nav-brand { display: flex; align-items: center; gap: 0.75rem; }
    .nav-icon { font-size: 1.4rem; color: #f59e0b; }
    .nav-title { font-size: 1.1rem; font-weight: 700; color: #e2e8f0; letter-spacing: 0.5px; }
    .nav-links a {
      color: #94a3b8; text-decoration: none; font-size: 0.9rem;
      padding: 0.35rem 0.9rem; border-radius: 6px; transition: all 0.2s;
    }
    .nav-links a:hover, .nav-links a.active { color: #e2e8f0; background: #2a3040; }
    .content { padding: 1.5rem 2rem; }

    /* User area */
    .nav-user {
      display: flex; align-items: center; gap: 0.6rem;
    }
    .user-name {
      font-size: 0.875rem; color: #cbd5e1; font-weight: 500;
    }
    .user-badge {
      font-size: 0.65rem; font-weight: 700; padding: 2px 8px;
      border-radius: 4px; letter-spacing: 0.5px; text-transform: uppercase;
    }
    .user-badge.role-admin      { background: rgba(239,68,68,0.15);  color: #f87171; }
    .user-badge.role-operator   { background: rgba(59,130,246,0.15); color: #60a5fa; }
    .user-badge.role-supervisor { background: rgba(168,85,247,0.15); color: #c084fc; }

    .logout-btn {
      background: none; border: 1px solid #2a3040; color: #94a3b8;
      cursor: pointer; border-radius: 6px; padding: 4px 10px;
      font-size: 1rem; transition: all 0.2s; line-height: 1;
    }
    .logout-btn:hover { background: #2a3040; color: #f87171; border-color: #f87171; }
  `]
})
export class AppComponent {
  auth = inject(AuthService);
}
