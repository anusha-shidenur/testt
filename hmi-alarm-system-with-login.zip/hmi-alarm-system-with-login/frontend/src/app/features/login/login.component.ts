import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="login-page">
      <div class="login-card">

        <!-- Brand -->
        <div class="login-brand">
          <span class="brand-icon">⚠</span>
          <div class="brand-text">
            <span class="brand-title">HMI Alarm System</span>
            <span class="brand-sub">Operator Access Portal</span>
          </div>
        </div>

        <!-- Form -->
        <form (ngSubmit)="onSubmit()" #loginForm="ngForm" class="login-form" autocomplete="off">

          <div class="form-group">
            <label for="username">Username</label>
            <div class="input-wrap">
              <span class="input-icon">👤</span>
              <input
                id="username"
                name="username"
                type="text"
                [(ngModel)]="username"
                placeholder="Enter your username"
                required
                autocomplete="username"
                [disabled]="loading()"
              />
            </div>
          </div>

          <div class="form-group">
            <label for="password">Password</label>
            <div class="input-wrap">
              <span class="input-icon">🔒</span>
              <input
                id="password"
                name="password"
                [type]="showPassword() ? 'text' : 'password'"
                [(ngModel)]="password"
                placeholder="Enter your password"
                required
                autocomplete="current-password"
                [disabled]="loading()"
              />
              <button
                type="button"
                class="eye-btn"
                (click)="showPassword.set(!showPassword())"
                tabindex="-1"
              >{{ showPassword() ? '🙈' : '👁' }}</button>
            </div>
          </div>

          @if (errorMsg()) {
            <div class="error-banner">
              <span>⚠</span>
              {{ errorMsg() }}
            </div>
          }

          <button
            type="submit"
            class="login-btn"
            [disabled]="loading() || !username || !password"
          >
            @if (loading()) {
              <span class="spinner"></span> Authenticating…
            } @else {
              Sign In
            }
          </button>
        </form>

        <!-- Default credentials hint (dev only) -->
        <div class="hint-box">
          <p class="hint-title">Default credentials</p>
          <div class="hint-row"><span class="role admin">ADMIN</span><code>admin / admin123</code></div>
          <div class="hint-row"><span class="role operator">OPERATOR</span><code>operator1 / operator123</code></div>
          <div class="hint-row"><span class="role supervisor">SUPERVISOR</span><code>supervisor1 / supervisor123</code></div>
        </div>

      </div>
    </div>
  `,
  styles: [`
    .login-page {
      min-height: 100vh;
      background: #0f1117;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 1rem;
      background-image:
        radial-gradient(ellipse at 20% 50%, rgba(245,158,11,0.06) 0%, transparent 60%),
        radial-gradient(ellipse at 80% 20%, rgba(59,130,246,0.05) 0%, transparent 50%);
    }

    .login-card {
      width: 100%;
      max-width: 420px;
      background: #161b27;
      border: 1px solid #2a3040;
      border-radius: 16px;
      padding: 2.5rem 2rem;
      box-shadow: 0 24px 64px rgba(0,0,0,0.5);
    }

    /* Brand */
    .login-brand {
      display: flex;
      align-items: center;
      gap: 1rem;
      margin-bottom: 2rem;
    }
    .brand-icon {
      font-size: 2.2rem;
      color: #f59e0b;
      line-height: 1;
      filter: drop-shadow(0 0 10px rgba(245,158,11,0.5));
    }
    .brand-text {
      display: flex;
      flex-direction: column;
    }
    .brand-title {
      font-size: 1.25rem;
      font-weight: 700;
      color: #e2e8f0;
      letter-spacing: 0.3px;
    }
    .brand-sub {
      font-size: 0.75rem;
      color: #64748b;
      letter-spacing: 0.5px;
      text-transform: uppercase;
      margin-top: 2px;
    }

    /* Form */
    .login-form { display: flex; flex-direction: column; gap: 1.25rem; }

    .form-group { display: flex; flex-direction: column; gap: 0.5rem; }
    .form-group label {
      font-size: 0.82rem;
      font-weight: 600;
      color: #94a3b8;
      letter-spacing: 0.5px;
      text-transform: uppercase;
    }

    .input-wrap {
      position: relative;
      display: flex;
      align-items: center;
    }
    .input-icon {
      position: absolute;
      left: 0.85rem;
      font-size: 0.95rem;
      pointer-events: none;
      opacity: 0.6;
    }
    .input-wrap input {
      width: 100%;
      padding: 0.75rem 0.9rem 0.75rem 2.5rem;
      background: #0f1117;
      border: 1px solid #2a3040;
      border-radius: 8px;
      color: #e2e8f0;
      font-size: 0.95rem;
      transition: border-color 0.2s, box-shadow 0.2s;
      outline: none;
    }
    .input-wrap input:focus {
      border-color: #f59e0b;
      box-shadow: 0 0 0 3px rgba(245,158,11,0.15);
    }
    .input-wrap input:disabled { opacity: 0.5; cursor: not-allowed; }
    .input-wrap input::placeholder { color: #475569; }

    .eye-btn {
      position: absolute;
      right: 0.85rem;
      background: none;
      border: none;
      cursor: pointer;
      font-size: 1rem;
      padding: 0;
      opacity: 0.7;
      transition: opacity 0.2s;
    }
    .eye-btn:hover { opacity: 1; }

    /* Error */
    .error-banner {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      padding: 0.7rem 1rem;
      background: rgba(239,68,68,0.12);
      border: 1px solid rgba(239,68,68,0.3);
      border-radius: 8px;
      color: #f87171;
      font-size: 0.875rem;
    }

    /* Login button */
    .login-btn {
      margin-top: 0.5rem;
      width: 100%;
      padding: 0.85rem;
      background: #f59e0b;
      color: #0f1117;
      border: none;
      border-radius: 8px;
      font-size: 0.95rem;
      font-weight: 700;
      cursor: pointer;
      transition: all 0.2s;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 0.5rem;
      letter-spacing: 0.3px;
    }
    .login-btn:hover:not(:disabled) {
      background: #fbbf24;
      box-shadow: 0 4px 20px rgba(245,158,11,0.35);
      transform: translateY(-1px);
    }
    .login-btn:active:not(:disabled) { transform: translateY(0); }
    .login-btn:disabled { opacity: 0.55; cursor: not-allowed; transform: none; }

    /* Spinner */
    .spinner {
      width: 16px;
      height: 16px;
      border: 2px solid rgba(15,17,23,0.3);
      border-top-color: #0f1117;
      border-radius: 50%;
      animation: spin 0.7s linear infinite;
    }
    @keyframes spin { to { transform: rotate(360deg); } }

    /* Hint box */
    .hint-box {
      margin-top: 1.75rem;
      padding: 1rem;
      background: rgba(42,48,64,0.4);
      border: 1px solid #2a3040;
      border-radius: 8px;
    }
    .hint-title {
      font-size: 0.72rem;
      color: #64748b;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      font-weight: 600;
      margin-bottom: 0.6rem;
    }
    .hint-row {
      display: flex;
      align-items: center;
      gap: 0.6rem;
      margin-bottom: 0.35rem;
      font-size: 0.82rem;
    }
    .hint-row code { color: #94a3b8; }
    .role {
      font-size: 0.65rem;
      font-weight: 700;
      padding: 2px 7px;
      border-radius: 4px;
      letter-spacing: 0.5px;
      min-width: 72px;
      text-align: center;
    }
    .role.admin       { background: rgba(239,68,68,0.15);  color: #f87171; }
    .role.operator    { background: rgba(59,130,246,0.15); color: #60a5fa; }
    .role.supervisor  { background: rgba(168,85,247,0.15); color: #c084fc; }
  `]
})
export class LoginComponent {
  username = '';
  password = '';
  loading  = signal(false);
  errorMsg = signal('');
  showPassword = signal(false);

  constructor(private authService: AuthService, private router: Router) {}

  onSubmit(): void {
    if (!this.username || !this.password) return;
    this.loading.set(true);
    this.errorMsg.set('');

    this.authService.login({ username: this.username, password: this.password }).subscribe({
      next: res => {
        this.loading.set(false);
        if (res.success) {
          this.router.navigate(['/alarms']);
        } else {
          this.errorMsg.set(res.message || 'Login failed');
        }
      },
      error: err => {
        this.loading.set(false);
        const msg = err?.error?.message || 'Invalid username or password';
        this.errorMsg.set(msg);
      }
    });
  }
}
