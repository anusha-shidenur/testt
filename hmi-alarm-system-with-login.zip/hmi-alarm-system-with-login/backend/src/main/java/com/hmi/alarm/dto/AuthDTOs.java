package com.hmi.alarm.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

public class AuthDTOs {

    @Data
    public static class LoginRequest {
        @NotBlank
        @Size(min = 3, max = 60)
        private String username;

        @NotBlank
        @Size(min = 4, max = 100)
        private String password;
    }

    @Data
    @lombok.Builder
    @lombok.AllArgsConstructor
    @lombok.NoArgsConstructor
    public static class LoginResponse {
        private String token;
        private String username;
        private String role;
        private long expiresIn;  // seconds
    }

    @Data
    public static class RegisterRequest {
        @NotBlank
        @Size(min = 3, max = 60)
        private String username;

        @NotBlank
        @Size(min = 8, max = 100)
        private String password;

        @NotBlank
        private String role;   // OPERATOR, SUPERVISOR, ADMIN
    }
}
