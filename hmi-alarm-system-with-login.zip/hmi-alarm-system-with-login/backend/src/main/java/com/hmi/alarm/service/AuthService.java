package com.hmi.alarm.service;

import com.hmi.alarm.dto.AuthDTOs;

public interface AuthService {
    AuthDTOs.LoginResponse login(AuthDTOs.LoginRequest request);
    void register(AuthDTOs.RegisterRequest request);
}
