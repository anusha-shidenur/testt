import { Injectable } from '@angular/core';
import { AlarmService } from './alarm.service';
import { Severity } from '../models/alarm.model';

const MESSAGES: Record<Severity, string[]> = {
  CRITICAL: [
    'Emergency shutdown triggered on Unit-A',
    'Reactor temperature exceeding safe limit',
    'Main power supply failure detected',
    'Fire suppression system activated',
    'Pressure vessel breach imminent',
  ],
  HIGH: [
    'Coolant flow rate below threshold',
    'Compressor vibration anomaly detected',
    'Motor overload on Pump-3',
    'Hydraulic pressure drop in Line-B',
    'Network communication loss on PLC-2',
  ],
  MEDIUM: [
    'Bearing temperature rising on Fan-5',
    'Level sensor calibration drift',
    'Valve actuator response slow',
    'Air filter pressure differential high',
    'Conveyor belt speed variance detected',
  ],
  LOW: [
    'Scheduled maintenance overdue for Unit-C',
    'Battery backup level below 40%',
    'Humidity sensor reading out of range',
    'Ambient temperature approaching limit',
    'Log storage usage above 80%',
  ],
};

const SEVERITIES: Severity[] = ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'];
const SEVERITY_WEIGHTS = [35, 35, 20, 10]; // weighted probability

let counter = 1000;

@Injectable({ providedIn: 'root' })
export class AlarmGeneratorService {

  private intervalRef: ReturnType<typeof setInterval> | null = null;

  constructor(private alarmService: AlarmService) {}

  start(intervalMs = 5000, onGenerated?: () => void): void {
    this.stop();
    this.intervalRef = setInterval(() => {
      this.generateOne(() => onGenerated?.());
    }, intervalMs);
  }

  stop(): void {
    if (this.intervalRef !== null) {
      clearInterval(this.intervalRef);
      this.intervalRef = null;
    }
  }

  generateOne(callback?: () => void): void {
    const severity = this.weightedRandom();
    const msgs = MESSAGES[severity];
    const message = msgs[Math.floor(Math.random() * msgs.length)];
    const code = `ALM-${String(++counter).padStart(4, '0')}`;

    this.alarmService.createAlarm({ code, message, severity }).subscribe({
      next: () => callback?.(),
      error: () => {} // silently ignore if backend is down
    });
  }

  isRunning(): boolean {
    return this.intervalRef !== null;
  }

  private weightedRandom(): Severity {
    const total = SEVERITY_WEIGHTS.reduce((a, b) => a + b, 0);
    let r = Math.random() * total;
    for (let i = 0; i < SEVERITIES.length; i++) {
      r -= SEVERITY_WEIGHTS[i];
      if (r <= 0) return SEVERITIES[i];
    }
    return 'LOW';
  }
}
