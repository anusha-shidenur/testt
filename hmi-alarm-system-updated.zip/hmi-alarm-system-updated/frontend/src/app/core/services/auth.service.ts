import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

export interface User {
  username: string;
  displayName: string;
}

const USERS: { username: string; password: string; displayName: string }[] = [
  { username: 'operator1', password: 'operator123', displayName: 'Operator 1' },
  { username: 'operator2', password: 'operator123', displayName: 'Operator 2' },
  { username: 'admin',     password: 'admin123',    displayName: 'Admin'       },
];

const STORAGE_KEY = 'hmi_user';

@Injectable({ providedIn: 'root' })
export class AuthService {
  constructor(private router: Router) {}

  login(username: string, password: string): boolean {
    const match = USERS.find(u => u.username === username && u.password === password);
    if (match) {
      sessionStorage.setItem(STORAGE_KEY, JSON.stringify({ username: match.username, displayName: match.displayName }));
      return true;
    }
    return false;
  }

  logout(): void {
    sessionStorage.removeItem(STORAGE_KEY);
    this.router.navigate(['/login']);
  }

  getCurrentUser(): User | null {
    const raw = sessionStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : null;
  }

  isLoggedIn(): boolean {
    return !!this.getCurrentUser();
  }

  isAdmin(): boolean {
    return this.getCurrentUser()?.username === 'admin';
  }
}
