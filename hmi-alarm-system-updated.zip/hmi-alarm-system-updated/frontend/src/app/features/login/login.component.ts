import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';

interface FieldError {
  username: string;
  password: string;
}

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {
  username = '';
  password = '';
  showPassword = false;
  loading = false;
  loginError = '';

  touched = { username: false, password: false };

  errors: FieldError = { username: '', password: '' };

  constructor(private auth: AuthService, private router: Router) {}

  validateUsername(): void {
    const v = this.username.trim();
    if (!v) {
      this.errors.username = 'Username is required.';
    } else if (v.length < 3) {
      this.errors.username = 'Username must be at least 3 characters.';
    } else if (/\s/.test(v)) {
      this.errors.username = 'Username cannot contain spaces.';
    } else if (!/^[a-zA-Z0-9_]+$/.test(v)) {
      this.errors.username = 'Only letters, numbers and underscores allowed.';
    } else {
      this.errors.username = '';
    }
  }

  validatePassword(): void {
    const v = this.password;
    if (!v) {
      this.errors.password = 'Password is required.';
    } else if (v.length < 6) {
      this.errors.password = 'Password must be at least 6 characters.';
    } else {
      this.errors.password = '';
    }
  }

  onBlurUsername(): void {
    this.touched.username = true;
    this.validateUsername();
  }

  onBlurPassword(): void {
    this.touched.password = true;
    this.validatePassword();
  }

  get isFormValid(): boolean {
    return !this.errors.username && !this.errors.password &&
           this.username.trim().length > 0 && this.password.length > 0;
  }

  onSubmit(): void {
    this.touched = { username: true, password: true };
    this.validateUsername();
    this.validatePassword();
    if (!this.isFormValid) return;

    this.loginError = '';
    this.loading = true;
    setTimeout(() => {
      const ok = this.auth.login(this.username.trim(), this.password);
      this.loading = false;
      if (ok) {
        this.router.navigate(['/alarms']);
      } else {
        this.loginError = 'Invalid username or password. Please try again.';
      }
    }, 600);
  }

  fillCredential(username: string, password: string): void {
    this.username = username;
    this.password = password;
    this.loginError = '';
    this.touched = { username: false, password: false };
    this.errors = { username: '', password: '' };
  }
}
