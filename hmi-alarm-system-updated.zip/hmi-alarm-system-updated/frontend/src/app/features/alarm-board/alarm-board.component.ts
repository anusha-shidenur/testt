import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { Subject, interval } from 'rxjs';
import { takeUntil, startWith } from 'rxjs/operators';
import { AlarmService } from '../../core/services/alarm.service';
import { AlarmGeneratorService } from '../../core/services/alarm-generator.service';
import { AuthService } from '../../core/services/auth.service';
import {
  Alarm, AlarmStats, AlarmFilterParams, Severity, AlarmRequest
} from '../../core/models/alarm.model';
import { SeverityBadgeComponent } from '../../shared/components/severity-badge.component';

@Component({
  selector: 'app-alarm-board',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule, SeverityBadgeComponent],
  templateUrl: './alarm-board.component.html',
  styleUrls: ['./alarm-board.component.scss']
})
export class AlarmBoardComponent implements OnInit, OnDestroy {

  alarms: Alarm[] = [];
  stats: AlarmStats | null = null;
  loading = false;
  error: string | null = null;

  // Filters
  filters: AlarmFilterParams = { page: 0, size: 10, sortBy: 'createdAt', sortDir: 'desc' };
  totalElements = 0;
  totalPages = 0;

  // Create alarm form
  showCreateForm = false;
  createForm: AlarmRequest = { code: '', message: '', severity: 'HIGH' };
  createLoading = false;
  createError: string | null = null;

  // Ack modal
  showAckModal = false;
  ackTargetAlarm: Alarm | null = null;
  ackBy = '';
  ackRemarks = '';
  ackLoading = false;

  severities: Severity[] = ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'];
  pageSizeOptions = [5, 10, 20, 50];

  private destroy$ = new Subject<void>();

  constructor(
    private alarmService: AlarmService,
    public generator: AlarmGeneratorService,
    public auth: AuthService
  ) {}

  ngOnInit(): void {
    this.loadData();
    interval(10000).pipe(
      takeUntil(this.destroy$),
      startWith(0)
    ).subscribe(() => this.loadStats());
  }

  ngOnDestroy(): void {
    this.generator.stop();
    this.destroy$.next();
    this.destroy$.complete();
  }

  loadData(): void {
    this.loading = true;
    this.error = null;
    this.alarmService.getAlarms(this.filters).subscribe({
      next: (paged) => {
        this.alarms = paged.content;
        this.totalElements = paged.totalElements;
        this.totalPages = paged.totalPages;
        this.loading = false;
      },
      error: (err) => {
        this.error = err.message;
        this.loading = false;
      }
    });
  }

  loadStats(): void {
    this.alarmService.getStats().subscribe({
      next: (stats) => this.stats = stats,
      error: () => {}
    });
  }

  applyFilter(): void {
    this.filters.page = 0;
    this.loadData();
  }

  onPageSizeChange(): void {
    this.filters.page = 0;
    this.loadData();
  }

  clearFilters(): void {
    this.filters = { page: 0, size: 10, sortBy: 'createdAt', sortDir: 'desc' };
    this.loadData();
  }

  goToPage(page: number): void {
    if (page < 0 || page >= this.totalPages) return;
    this.filters.page = page;
    this.loadData();
  }

  // Random generator
  toggleGenerator(): void {
    if (this.generator.isRunning()) {
      this.generator.stop();
    } else {
      this.generator.start(5000, () => {
        this.loadData();
        this.loadStats();
      });
    }
  }

  generateOne(): void {
    this.generator.generateOne(() => {
      this.loadData();
      this.loadStats();
    });
  }

  // Create
  openCreateForm(): void {
    this.showCreateForm = true;
    this.createForm = { code: '', message: '', severity: 'HIGH' };
    this.createError = null;
  }

  submitCreate(): void {
    if (!this.createForm.code || !this.createForm.message) {
      this.createError = 'Code and message are required.';
      return;
    }
    this.createLoading = true;
    this.alarmService.createAlarm(this.createForm).subscribe({
      next: () => {
        this.showCreateForm = false;
        this.createLoading = false;
        this.loadData();
        this.loadStats();
      },
      error: (err) => {
        this.createError = err.message;
        this.createLoading = false;
      }
    });
  }

  // Acknowledge
  openAckModal(alarm: Alarm): void {
    this.ackTargetAlarm = alarm;
    this.ackBy = this.auth.getCurrentUser()?.username ?? '';
    this.ackRemarks = '';
    this.showAckModal = true;
  }

  submitAck(): void {
    if (!this.ackTargetAlarm || !this.ackBy.trim()) return;
    this.ackLoading = true;
    this.alarmService.acknowledgeAlarm(this.ackTargetAlarm.id, {
      acknowledgedBy: this.ackBy,
      remarks: this.ackRemarks
    }).subscribe({
      next: () => {
        this.showAckModal = false;
        this.ackLoading = false;
        this.loadData();
        this.loadStats();
      },
      error: (err) => {
        this.error = err.message;
        this.ackLoading = false;
      }
    });
  }

  clearAlarm(alarm: Alarm): void {
    if (!confirm(`Clear alarm "${alarm.code}"?`)) return;
    this.alarmService.clearAlarm(alarm.id).subscribe({
      next: () => { this.loadData(); this.loadStats(); },
      error: (err) => this.error = err.message
    });
  }

  deleteAlarm(alarm: Alarm): void {
    if (!confirm(`Permanently delete alarm "${alarm.code}"?`)) return;
    this.alarmService.deleteAlarm(alarm.id).subscribe({
      next: () => { this.loadData(); this.loadStats(); },
      error: (err) => this.error = err.message
    });
  }

  trackById(_: number, alarm: Alarm): number { return alarm.id; }

  get currentPage(): number { return this.filters.page ?? 0; }

  get visiblePages(): number[] {
    const total = this.totalPages;
    const cur = this.currentPage;
    if (total <= 7) return Array.from({ length: total }, (_, i) => i);
    const pages: number[] = [];
    pages.push(0);
    if (cur > 2) pages.push(-1); // ellipsis
    for (let i = Math.max(1, cur - 1); i <= Math.min(total - 2, cur + 1); i++) pages.push(i);
    if (cur < total - 3) pages.push(-2); // ellipsis
    pages.push(total - 1);
    return pages;
  }

  getSeverityCount(sev: Severity): number {
    return this.stats?.activeBySeverity?.[sev] ?? 0;
  }

  getDonutDashArray(sev: Severity): string {
    const total = this.stats?.totalActive ?? 0;
    if (total === 0) return '0 100';
    const pct = (this.getSeverityCount(sev) / total) * 100;
    return `${pct.toFixed(1)} ${(100 - pct).toFixed(1)}`;
  }

  get startRecord(): number {
    return (this.currentPage * (this.filters.size ?? 10)) + 1;
  }
  get endRecord(): number {
    return Math.min((this.currentPage + 1) * (this.filters.size ?? 10), this.totalElements);
  }
}
