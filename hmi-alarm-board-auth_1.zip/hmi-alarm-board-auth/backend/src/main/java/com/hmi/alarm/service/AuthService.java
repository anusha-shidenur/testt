package com.hmi.alarm.service;

import com.hmi.alarm.dto.AuthDtos.AuthResponse;
import com.hmi.alarm.dto.AuthDtos.LoginRequest;
import com.hmi.alarm.dto.AuthDtos.RegisterRequest;
import com.hmi.alarm.entity.User;
import com.hmi.alarm.repository.UserRepository;
import com.hmi.alarm.security.JwtUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;
    private final AuthenticationManager authenticationManager;

    public AuthResponse register(RegisterRequest request) {
        if (userRepository.existsByUsername(request.username())) {
            throw new IllegalArgumentException("Username '" + request.username() + "' is already taken");
        }

        User user = User.builder()
            .username(request.username())
            .password(passwordEncoder.encode(request.password()))
            .displayName(request.displayName())
            .role(request.role())
            .build();

        userRepository.save(user);
        log.info("Registered new user: {} with role: {}", user.getUsername(), user.getRole());

        String token = jwtUtil.generateToken(user);
        return new AuthResponse(token, user.getUsername(), user.getDisplayName(), user.getRole().name());
    }

    public AuthResponse login(LoginRequest request) {
        authenticationManager.authenticate(
            new UsernamePasswordAuthenticationToken(request.username(), request.password())
        );

        User user = userRepository.findByUsername(request.username())
            .orElseThrow(() -> new IllegalArgumentException("User not found"));

        log.info("User logged in: {} (role: {})", user.getUsername(), user.getRole());
        String token = jwtUtil.generateToken(user);
        return new AuthResponse(token, user.getUsername(), user.getDisplayName(), user.getRole().name());
    }
}
