package com.hmi.alarm.config;

import org.springframework.context.annotation.Configuration;

/**
 * Web MVC configuration.
 * CORS is handled by SecurityConfig (CorsConfigurationSource bean).
 */
@Configuration
public class WebConfig {
    // CORS is configured in SecurityConfig to work correctly with Spring Security
}
