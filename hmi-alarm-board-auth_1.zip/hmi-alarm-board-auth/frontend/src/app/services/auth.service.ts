import { Injectable, signal, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from '../../environments/environment';

export type UserRole = 'ADMIN' | 'OPERATOR';

export interface User {
  username: string;
  role: UserRole;
  displayName: string;
}

export interface AuthResponse {
  token: string;
  username: string;
  displayName: string;
  role: UserRole;
}

export interface ApiResponse<T> {
  success: boolean;
  message: string;
  statusCode: number;
  data: T;
}

export interface RegisterRequest {
  username: string;
  password: string;
  displayName: string;
  role: UserRole;
}

export interface LoginRequest {
  username: string;
  password: string;
}

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly http = inject(HttpClient);
  private readonly base = `${environment.apiBaseUrl}/auth`;
  private readonly TOKEN_KEY = 'hmi_jwt_token';
  private readonly USER_KEY  = 'hmi_auth_user';

  private _currentUser = signal<User | null>(this.loadUserFromStorage());
  private _token = signal<string | null>(this.loadTokenFromStorage());

  get currentUser() { return this._currentUser(); }
  get token()       { return this._token(); }
  get isLoggedIn()  { return this._currentUser() !== null && this._token() !== null; }
  get isAdmin()     { return this._currentUser()?.role === 'ADMIN'; }
  get isOperator()  { return this._currentUser()?.role === 'OPERATOR'; }

  register(request: RegisterRequest): Observable<AuthResponse> {
    return this.http.post<ApiResponse<AuthResponse>>(`${this.base}/register`, request)
      .pipe(
        map(r => r.data),
        tap(data => this.persistSession(data))
      );
  }

  login(request: LoginRequest): Observable<AuthResponse> {
    return this.http.post<ApiResponse<AuthResponse>>(`${this.base}/login`, request)
      .pipe(
        map(r => r.data),
        tap(data => this.persistSession(data))
      );
  }

  logout(): void {
    this._currentUser.set(null);
    this._token.set(null);
    sessionStorage.removeItem(this.TOKEN_KEY);
    sessionStorage.removeItem(this.USER_KEY);
  }

  private persistSession(data: AuthResponse): void {
    const user: User = {
      username: data.username,
      displayName: data.displayName,
      role: data.role
    };
    this._currentUser.set(user);
    this._token.set(data.token);
    sessionStorage.setItem(this.TOKEN_KEY, data.token);
    sessionStorage.setItem(this.USER_KEY, JSON.stringify(user));
  }

  private loadUserFromStorage(): User | null {
    try {
      const raw = sessionStorage.getItem(this.USER_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch { return null; }
  }

  private loadTokenFromStorage(): string | null {
    return sessionStorage.getItem(this.TOKEN_KEY);
  }
}
