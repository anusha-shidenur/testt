package com.hmi.alarm.entity;

public enum Role {
    ADMIN,
    OPERATOR
}
