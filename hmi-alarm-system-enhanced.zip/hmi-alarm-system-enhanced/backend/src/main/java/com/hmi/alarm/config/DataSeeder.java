package com.hmi.alarm.config;

import com.hmi.alarm.entity.*;
import com.hmi.alarm.repository.AlarmEventRepository;
import com.hmi.alarm.repository.AlarmRepository;
import com.hmi.alarm.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.List;

@Configuration
@RequiredArgsConstructor
@Slf4j
public class DataSeeder {

    private final AlarmRepository alarmRepository;
    private final AlarmEventRepository alarmEventRepository;
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Bean
    @Profile("!test")
    public CommandLineRunner seedData() {
        return args -> {
            seedUsers();
            seedAlarms();
        };
    }

    private void seedUsers() {
        if (userRepository.count() > 0) {
            log.info("Users already seeded — skipping.");
            return;
        }
        log.info("Seeding default users...");
        List<AppUser> users = List.of(
            AppUser.builder().username("admin").password(passwordEncoder.encode("admin123"))
                .fullName("System Administrator").role(Role.ADMIN).enabled(true).build(),
            AppUser.builder().username("operator1").password(passwordEncoder.encode("operator123"))
                .fullName("John Operator").role(Role.OPERATOR).enabled(true).build(),
            AppUser.builder().username("operator2").password(passwordEncoder.encode("operator123"))
                .fullName("Jane Smith").role(Role.OPERATOR).enabled(true).build()
        );
        userRepository.saveAll(users);
        log.info("Seeded {} users. admin/admin123, operator1/operator123", users.size());
    }

    private void seedAlarms() {
        if (alarmRepository.count() > 0) {
            log.info("Alarms already seeded — skipping.");
            return;
        }
        log.info("Seeding sample alarms...");
        List<Alarm> alarms = List.of(
            Alarm.builder().code("ALM-001").message("High temperature on boiler unit 3").severity(Severity.CRITICAL).active(true).acknowledged(false).build(),
            Alarm.builder().code("ALM-002").message("Pressure sensor reading out of range").severity(Severity.HIGH).active(true).acknowledged(false).build(),
            Alarm.builder().code("ALM-003").message("Fan speed below threshold on HVAC-2").severity(Severity.MEDIUM).active(true).acknowledged(true).acknowledgedBy("operator1").build(),
            Alarm.builder().code("ALM-004").message("Low coolant level detected").severity(Severity.LOW).active(false).acknowledged(true).acknowledgedBy("operator2").build(),
            Alarm.builder().code("ALM-005").message("Emergency stop triggered on conveyor").severity(Severity.CRITICAL).active(true).acknowledged(false).build(),
            Alarm.builder().code("ALM-006").message("Voltage fluctuation on panel B").severity(Severity.HIGH).active(true).acknowledged(false).build(),
            Alarm.builder().code("ALM-007").message("Hydraulic pressure drop detected").severity(Severity.MEDIUM).active(true).acknowledged(false).build(),
            Alarm.builder().code("ALM-008").message("Conveyor belt speed variance").severity(Severity.LOW).active(false).acknowledged(false).build()
        );
        List<Alarm> saved = alarmRepository.saveAll(alarms);
        for (Alarm alarm : saved) {
            alarmEventRepository.save(AlarmEvent.builder().alarm(alarm).state(AlarmState.RAISED).remarks("System generated alarm").build());
            if (alarm.getAcknowledged()) {
                alarmEventRepository.save(AlarmEvent.builder().alarm(alarm).state(AlarmState.ACKNOWLEDGED).remarks("Acknowledged by " + alarm.getAcknowledgedBy()).build());
            }
            if (!alarm.getActive()) {
                alarmEventRepository.save(AlarmEvent.builder().alarm(alarm).state(AlarmState.CLEARED).remarks("Alarm resolved and cleared").build());
            }
        }
        log.info("Seeded {} alarms.", saved.size());
    }
}
