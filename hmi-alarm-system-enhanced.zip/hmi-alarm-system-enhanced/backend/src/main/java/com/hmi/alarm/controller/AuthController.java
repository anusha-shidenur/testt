package com.hmi.alarm.controller;

import com.hmi.alarm.dto.ApiResponse;
import com.hmi.alarm.dto.LoginRequestDTO;
import com.hmi.alarm.dto.LoginResponseDTO;
import com.hmi.alarm.entity.AppUser;
import com.hmi.alarm.repository.UserRepository;
import com.hmi.alarm.security.JwtTokenProvider;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/auth")
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:4200")
public class AuthController {

    private final AuthenticationManager authenticationManager;
    private final JwtTokenProvider jwtTokenProvider;
    private final UserRepository userRepository;

    @PostMapping("/login")
    public ApiResponse<LoginResponseDTO> login(@Valid @RequestBody LoginRequestDTO request) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword())
        );

        UserDetails userDetails = (UserDetails) authentication.getPrincipal();
        AppUser user = userRepository.findByUsername(userDetails.getUsername()).orElseThrow();

        String token = jwtTokenProvider.generateToken(userDetails, user.getRole().name());

        LoginResponseDTO response = LoginResponseDTO.builder()
                .token(token)
                .username(user.getUsername())
                .fullName(user.getFullName())
                .role(user.getRole().name())
                .expiresIn(86400000L)
                .build();

        return ApiResponse.success(response, "Login successful");
    }
}
