import { Routes } from '@angular/router';
import { authGuard } from './core/guards/auth.guard';

export const routes: Routes = [
  {
    path: 'login',
    loadComponent: () =>
      import('./features/login/login.component').then(m => m.LoginComponent)
  },
  {
    path: '',
    redirectTo: 'alarms',
    pathMatch: 'full'
  },
  {
    path: 'alarms',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./features/alarm-board/alarm-board.component').then(m => m.AlarmBoardComponent)
  },
  {
    path: 'alarms/:id',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./features/alarm-detail/alarm-detail.component').then(m => m.AlarmDetailComponent)
  },
  {
    path: '**',
    redirectTo: 'alarms'
  }
];
