// Enums
export type Severity = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
export type AlarmState = 'RAISED' | 'ACKNOWLEDGED' | 'CLEARED';
export type UserRole = 'ADMIN' | 'OPERATOR';

// Alarm model
export interface Alarm {
  id: number;
  code: string;
  message: string;
  severity: Severity;
  active: boolean;
  acknowledged: boolean;
  acknowledgedBy: string | null;
  acknowledgedAt: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface AlarmEvent {
  id: number;
  alarmId: number;
  ts: string;
  state: AlarmState;
  remarks: string;
}

export interface AlarmRequest {
  code: string;
  message: string;
  severity: Severity;
}

export interface AcknowledgeRequest {
  acknowledgedBy: string;
  remarks?: string;
}

export interface PagedResponse<T> {
  content: T[];
  pageNumber: number;
  pageSize: number;
  totalElements: number;
  totalPages: number;
  last: boolean;
}

export interface ApiResponse<T> {
  success: boolean;
  message: string;
  data: T;
  timestamp: string;
}

export interface AlarmStats {
  totalActive: number;
  totalCleared: number;
  totalAcknowledged: number;
  activeBySeverity: { [key in Severity]?: number };
}

export interface AlarmFilterParams {
  active?: boolean;
  severity?: Severity;
  page?: number;
  size?: number;
  sortBy?: string;
  sortDir?: 'asc' | 'desc';
}

export interface LoginRequest {
  username: string;
  password: string;
}

export interface LoginResponse {
  token: string;
  username: string;
  fullName: string;
  role: UserRole;
  expiresIn: number;
}

export interface AuthUser {
  username: string;
  fullName: string;
  role: UserRole;
}
