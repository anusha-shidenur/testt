import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { Subject, interval } from 'rxjs';
import { takeUntil, startWith } from 'rxjs/operators';
import { AlarmService } from '../../core/services/alarm.service';
import { AuthService } from '../../core/services/auth.service';
import {
  Alarm, AlarmStats, AlarmFilterParams, Severity, AlarmRequest
} from '../../core/models/alarm.model';
import { SeverityBadgeComponent } from '../../shared/components/severity-badge.component';

@Component({
  selector: 'app-alarm-board',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule, SeverityBadgeComponent],
  templateUrl: './alarm-board.component.html',
  styleUrls: ['./alarm-board.component.scss']
})
export class AlarmBoardComponent implements OnInit, OnDestroy {

  alarms: Alarm[] = [];
  stats: AlarmStats | null = null;
  loading = false;
  error: string | null = null;

  // Filters
  filters: AlarmFilterParams = { page: 0, size: 10, sortBy: 'createdAt', sortDir: 'desc' };
  totalElements = 0;
  totalPages = 0;

  // Create alarm form
  showCreateForm = false;
  createForm: AlarmRequest = { code: '', message: '', severity: 'HIGH' };
  createLoading = false;
  createError: string | null = null;
  formTouched = false;

  // Ack modal
  showAckModal = false;
  ackTargetAlarm: Alarm | null = null;
  ackBy = '';
  ackRemarks = '';
  ackLoading = false;
  ackTouched = false;

  severities: Severity[] = ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'];

  private destroy$ = new Subject<void>();

  constructor(
    private alarmService: AlarmService,
    public authService: AuthService
  ) {}

  ngOnInit(): void {
    this.loadData();
    interval(15000).pipe(
      takeUntil(this.destroy$),
      startWith(0)
    ).subscribe(() => this.loadStats());
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  loadData(): void {
    this.loading = true;
    this.error = null;
    this.alarmService.getAlarms(this.filters).subscribe({
      next: (paged) => {
        this.alarms = paged.content;
        this.totalElements = paged.totalElements;
        this.totalPages = paged.totalPages;
        this.loading = false;
      },
      error: (err) => {
        this.error = err.message;
        this.loading = false;
      }
    });
  }

  loadStats(): void {
    this.alarmService.getStats().subscribe({
      next: (stats) => this.stats = stats,
      error: () => {}
    });
  }

  applyFilter(): void {
    this.filters.page = 0;
    this.loadData();
  }

  clearFilters(): void {
    this.filters = { page: 0, size: 10, sortBy: 'createdAt', sortDir: 'desc' };
    this.loadData();
  }

  goToPage(page: number): void {
    if (page < 0 || page >= this.totalPages) return;
    this.filters.page = page;
    this.loadData();
  }

  openCreateForm(): void {
    this.showCreateForm = true;
    this.createForm = { code: '', message: '', severity: 'HIGH' };
    this.createError = null;
    this.formTouched = false;
  }

  submitCreate(): void {
    this.formTouched = true;
    if (!this.createForm.code.trim()) {
      this.createError = 'Alarm code is required.';
      return;
    }
    if (!this.createForm.message.trim()) {
      this.createError = 'Alarm message is required.';
      return;
    }
    if (this.createForm.code.trim().length > 50) {
      this.createError = 'Code cannot exceed 50 characters.';
      return;
    }
    this.createLoading = true;
    this.createError = null;
    this.alarmService.createAlarm(this.createForm).subscribe({
      next: () => {
        this.showCreateForm = false;
        this.createLoading = false;
        this.loadData();
        this.loadStats();
      },
      error: (err) => {
        this.createError = err.message;
        this.createLoading = false;
      }
    });
  }

  openAckModal(alarm: Alarm): void {
    this.ackTargetAlarm = alarm;
    this.ackBy = this.authService.currentUser?.username || '';
    this.ackRemarks = '';
    this.ackTouched = false;
    this.showAckModal = true;
  }

  submitAck(): void {
    this.ackTouched = true;
    if (!this.ackTargetAlarm || !this.ackBy.trim()) return;
    this.ackLoading = true;
    this.alarmService.acknowledgeAlarm(this.ackTargetAlarm.id, {
      acknowledgedBy: this.ackBy,
      remarks: this.ackRemarks
    }).subscribe({
      next: () => {
        this.showAckModal = false;
        this.ackLoading = false;
        this.loadData();
        this.loadStats();
      },
      error: (err) => {
        this.error = err.message;
        this.ackLoading = false;
      }
    });
  }

  clearAlarm(alarm: Alarm): void {
    if (!confirm(`Clear alarm "${alarm.code}"?`)) return;
    this.alarmService.clearAlarm(alarm.id).subscribe({
      next: () => { this.loadData(); this.loadStats(); },
      error: (err) => this.error = err.message
    });
  }

  deleteAlarm(alarm: Alarm): void {
    if (!this.authService.isAdmin) {
      this.error = 'Only Administrators can delete alarms.';
      return;
    }
    if (!confirm(`Permanently delete alarm "${alarm.code}"? This cannot be undone.`)) return;
    this.alarmService.deleteAlarm(alarm.id).subscribe({
      next: () => { this.loadData(); this.loadStats(); },
      error: (err) => this.error = err.message
    });
  }

  trackById(_: number, alarm: Alarm): number {
    return alarm.id;
  }

  get pagesArray(): number[] {
    return Array.from({ length: Math.min(this.totalPages, 10) }, (_, i) => i);
  }

  get pageStart(): number {
    return (this.filters.page! * this.filters.size!) + 1;
  }

  get pageEnd(): number {
    return Math.min((this.filters.page! + 1) * this.filters.size!, this.totalElements);
  }

  getSeverityCount(sev: Severity): number {
    return this.stats?.activeBySeverity?.[sev] ?? 0;
  }

  // Donut chart: Calculate proper dash offsets for stacked segments
  getDonutSegments(): { sev: Severity; color: string; pct: number; offset: number }[] {
    const total = this.stats?.totalActive ?? 0;
    if (total === 0) return [];

    const colors: Record<Severity, string> = {
      CRITICAL: '#ef4444',
      HIGH: '#f97316',
      MEDIUM: '#eab308',
      LOW: '#4ade80'
    };

    const circumference = 100; // working in % space
    let cumulativeOffset = 25; // start at top (-90deg)

    return this.severities.map(sev => {
      const count = this.getSeverityCount(sev);
      const pct = total > 0 ? (count / total) * 100 : 0;
      const offset = cumulativeOffset;
      cumulativeOffset -= pct;
      return { sev, color: colors[sev], pct, offset };
    }).filter(s => s.pct > 0);
  }
}
