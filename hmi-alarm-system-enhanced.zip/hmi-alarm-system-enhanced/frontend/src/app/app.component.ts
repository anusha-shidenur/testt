import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet, RouterLink, RouterLinkActive } from '@angular/router';
import { AuthService } from './core/services/auth.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterLink, RouterLinkActive],
  template: `
    <div class="app-shell">
      <header class="top-nav" *ngIf="authService.isLoggedIn">
        <div class="nav-left">
          <div class="nav-brand">
            <svg class="nav-icon" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
              <polygon points="20,4 36,32 4,32" fill="none" stroke="#f59e0b" stroke-width="2.5" stroke-linejoin="round"/>
              <line x1="20" y1="15" x2="20" y2="24" stroke="#f59e0b" stroke-width="2.5" stroke-linecap="round"/>
              <circle cx="20" cy="28" r="1.5" fill="#f59e0b"/>
            </svg>
            <span class="nav-title">HMI Alarm Board</span>
          </div>
          <nav class="nav-links">
            <a routerLink="/alarms" routerLinkActive="active">Dashboard</a>
          </nav>
        </div>
        <div class="nav-right">
          <div class="user-info">
            <div class="user-avatar">{{ getInitial() }}</div>
            <div class="user-details">
              <span class="user-name">{{ authService.currentUser?.fullName }}</span>
              <span class="user-role" [ngClass]="authService.currentUser?.role?.toLowerCase()">
                {{ authService.currentUser?.role }}
              </span>
            </div>
          </div>
          <button class="btn-logout" (click)="authService.logout()">
            <svg viewBox="0 0 20 20" fill="currentColor">
              <path fill-rule="evenodd" d="M3 3a1 1 0 00-1 1v12a1 1 0 102 0V4a1 1 0 00-1-1zm10.293 9.293a1 1 0 001.414 1.414l3-3a1 1 0 000-1.414l-3-3a1 1 0 10-1.414 1.414L14.586 9H7a1 1 0 100 2h7.586l-1.293 1.293z" clip-rule="evenodd"/>
            </svg>
            Logout
          </button>
        </div>
      </header>
      <main [class.content]="authService.isLoggedIn">
        <router-outlet />
      </main>
    </div>
  `,
  styles: [`
    .app-shell { min-height: 100vh; background: #0f1117; }
    .top-nav {
      display: flex; align-items: center; justify-content: space-between;
      padding: 0 1.5rem; height: 60px; background: #161b27;
      border-bottom: 1px solid #2a3040; position: sticky; top: 0; z-index: 100;
    }
    .nav-left { display: flex; align-items: center; gap: 1.5rem; }
    .nav-brand { display: flex; align-items: center; gap: 0.6rem; text-decoration: none; }
    .nav-icon { width: 28px; height: 28px; }
    .nav-title { font-size: 1rem; font-weight: 700; color: #e2e8f0; letter-spacing: 0.5px; white-space: nowrap; }
    .nav-links a {
      color: #64748b; text-decoration: none; font-size: 0.85rem;
      padding: 0.3rem 0.75rem; border-radius: 6px; transition: all 0.2s;
    }
    .nav-links a:hover, .nav-links a.active { color: #e2e8f0; background: #1e2535; }
    .nav-right { display: flex; align-items: center; gap: 1rem; }
    .user-info { display: flex; align-items: center; gap: 0.6rem; }
    .user-avatar {
      width: 32px; height: 32px; border-radius: 8px;
      background: linear-gradient(135deg, #1d4ed8, #2563eb);
      color: white; font-size: 0.85rem; font-weight: 700;
      display: flex; align-items: center; justify-content: center;
    }
    .user-details { display: flex; flex-direction: column; }
    .user-name { font-size: 0.8rem; font-weight: 600; color: #e2e8f0; line-height: 1.2; }
    .user-role {
      font-size: 0.65rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; line-height: 1.2;
      &.admin { color: #f59e0b; }
      &.operator { color: #60a5fa; }
    }
    .btn-logout {
      display: flex; align-items: center; gap: 0.4rem;
      background: transparent; border: 1px solid #2a3040;
      color: #64748b; padding: 0.3rem 0.75rem; border-radius: 6px;
      font-size: 0.8rem; cursor: pointer; transition: all 0.2s;
      svg { width: 14px; height: 14px; }
      &:hover { border-color: #4b5563; color: #e2e8f0; background: #1e2535; }
    }
    .content { padding: 1.5rem 2rem; }
  `]
})
export class AppComponent {
  constructor(public authService: AuthService) {}

  getInitial(): string {
    return (this.authService.currentUser?.fullName || 'U').charAt(0).toUpperCase();
  }
}
